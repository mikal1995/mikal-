/* ============================================================
   Mikal Narration — main.js
   Shared interactive features across all 5 pages.
   AI tool: Claude (Anthropic) — used for IntersectionObserver 
   and scroll-based animation logic.
   Each section explains WHAT it does and WHY.
============================================================ */

/* ── 1. DOM READY GUARD ───────────────────────────────────────
   Wrapping in DOMContentLoaded ensures the HTML is fully parsed
   before we try to select elements — avoids null errors.
────────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {

  /* ── 2. MOBILE NAV TOGGLE ─────────────────────────────────
     Hamburger button toggles the nav visibility on small screens.
     aria-expanded communicates state to screen readers.
  ────────────────────────────────────────────────────────── */
  const toggle = document.querySelector('.nav-toggle');
  const nav    = document.querySelector('#primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('nav--open');
    });

    // Close nav when a link inside it is clicked (mobile UX)
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('nav--open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ── 3. SCROLL PROGRESS BAR ───────────────────────────────
     A thin colored line at the very top of the page grows 
     as you scroll — gives users a sense of reading progress.
     Width = (scrolled / total scrollable) * 100%.
  ────────────────────────────────────────────────────────── */
  const progressBar = document.getElementById('scroll-progress');
  if (progressBar) {
    window.addEventListener('scroll', () => {
      const scrollTop  = window.scrollY;
      const docHeight  = document.documentElement.scrollHeight - window.innerHeight;
      const pct        = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
      progressBar.style.width = pct + '%';
    }, { passive: true });  // passive: true improves scroll performance
  }

  /* ── 4. HEADER SHADOW ON SCROLL ──────────────────────────
     Adds a shadow class once user scrolls 30px down.
     Gives visual separation between header and content.
  ────────────────────────────────────────────────────────── */
  const header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('header--scrolled', window.scrollY > 30);
    }, { passive: true });
  }

  /* ── 5. BACK-TO-TOP BUTTON ───────────────────────────────
     Button appears after scrolling 300px, smoothly scrolls
     the user back to the top of the page on click.
  ────────────────────────────────────────────────────────── */
  const backBtn = document.getElementById('back-to-top');
  if (backBtn) {
    window.addEventListener('scroll', () => {
      backBtn.classList.toggle('visible', window.scrollY > 300);
    }, { passive: true });

    backBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ── 6. DARK / LIGHT MODE TOGGLE ─────────────────────────
     Toggles data-theme="light" on the <html> element.
     CSS variables in style.css respond to this attribute.
     Saves the preference in localStorage so it persists
     across page loads and page navigations.
  ────────────────────────────────────────────────────────── */
  const themeBtn  = document.getElementById('theme-toggle');
  const htmlEl    = document.documentElement;

  // Apply saved preference on load
  const savedTheme = localStorage.getItem('mn-theme') || 'dark';
  if (savedTheme === 'light') htmlEl.setAttribute('data-theme', 'light');
  updateThemeLabel(savedTheme === 'light');

  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const isLight = htmlEl.getAttribute('data-theme') === 'light';
      if (isLight) {
        htmlEl.removeAttribute('data-theme');
        localStorage.setItem('mn-theme', 'dark');
        updateThemeLabel(false);
      } else {
        htmlEl.setAttribute('data-theme', 'light');
        localStorage.setItem('mn-theme', 'light');
        updateThemeLabel(true);
      }
    });
  }

  /* Updates button label and icon to reflect current mode */
  function updateThemeLabel(isLight) {
    if (!themeBtn) return;
    themeBtn.innerHTML = isLight
      ? '<span aria-hidden="true">🌙</span> Dark'
      : '<span aria-hidden="true">☀️</span> Light';
    themeBtn.setAttribute('aria-label', isLight ? 'Switch to dark mode' : 'Switch to light mode');
  }

  /* ── 7. SCROLL REVEAL (IntersectionObserver) ─────────────
     Elements with class .reveal start invisible (defined in CSS).
     Observer watches them; once 15% is in the viewport,
     adds .reveal--visible which triggers the CSS transition.
     unobserve() stops watching after first reveal (performance).
  ────────────────────────────────────────────────────────── */
  const revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length && 'IntersectionObserver' in window) {
    const revealObs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('reveal--visible');
          revealObs.unobserve(entry.target);  // stop watching — saves CPU
        }
      });
    }, { threshold: 0.15 });

    revealEls.forEach(el => revealObs.observe(el));
  } else {
    // Fallback: if IntersectionObserver unsupported, show all elements
    revealEls.forEach(el => el.classList.add('reveal--visible'));
  }

  /* ── 8. ACTIVE NAV LINK ───────────────────────────────────
     Compares current page filename to nav href to highlight
     the correct link. Helps users know which page they're on.
  ────────────────────────────────────────────────────────── */
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && (href === currentPage || (currentPage === '' && href === 'index.html'))) {
      link.classList.add('active');
    }
  });

});
